<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/resources/global/css/fonts.css')); ?>"
      type="text/css"/>


<!-- Local CSS 등록 -->
<!-- uk.css 제거로 인해 uk국가 제외한 국가들만 적용되도록 수정(220923) -->

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/resources/vn/css/vn.css')); ?>"
      type="text/css"/>


<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-dependencies.min.72b3474a5ea9ec2c8b38096685e0928d.css')); ?>"
      type="text/css">
<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-base.min.0af1157cb7ae76fa7ea2eb96300ac6b8.css')); ?>"
      type="text/css">


<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/epp/common/ep-cm-g-barcode-scanner-popup/clientlibs/site.min.5578572dd8752920eb8c98daf5371b4b.css')); ?>"
      type="text/css">


<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/clientlibs/epp/global/clientlib-templates/ep-page/compact.min.1681c034dd2a932f8aa0f6ae7fd44266.css')); ?>"
      type="text/css">


<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/common/cm-g-notice/clientlibs/site.min.759491f08c70ca0e350c3e4852ec1308.css')); ?>"
      type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/common/cm-g-text-block-container/clientlibs/site.min.215994cb1c3ba8835e60f639f58f53fc.css')); ?>"
      type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/home/ho-g-category-hscroll/clientlibs/site.min.c1f098f29ee1838efe3f432e426fdcd6.css')); ?>"
      type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/home/ho-g-home-kv-carousel/clientlibs/site.min.33f298a364de81e93c43a8b4e76ce29e.css')); ?>"
      type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/home/ho-g-showcase-card-tab/clientlibs/site.min.a8af04cc0ed3ecc4711b8c9f744c98db.css')); ?>"
      type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/offer/of-g-feature-benefit-card/clientlibs/site.min.cd082f0c4f3d22b3ac41703fdd8948da.css')); ?>"
      type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product/pd-g-feature-benefit-column-carousel/clientlibs/site.min.1ee176a8b4684007e853d28c1beac51f.css')); ?>"
      type="text/css"/>
<link rel="stylesheet" href="<?php echo e(asset('\www.samsung.com\etc.clientlibs\samsung\components\content\consumer\global\product\clientlibs\site.min.5a34e744757e41dc5dc7661f95a08ec2.css')); ?>" type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/offer/pd-g-offer-product-card-list/clientlibs/site.min.a0129c3a09e325045fc304f1731f5770.css')); ?>"
      type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/home/ho-g-home-search/clientlibs/site.min.60ae3f436cd1c4149ee1fef14e98ff06.css')); ?>"
      type="text/css"/>

<link rel="stylesheet"
      href="<?php echo e(asset('/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/common/cm-g-local-benefit/clientlibs/site.min.dabba97e52a3db5f5124b8de4b4ba2b8.css')); ?>"
      type="text/css"/>
      <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/resources/vn/css/vn.css')); ?>"
          type="text/css"/>


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-dependencies.min.72b3474a5ea9ec2c8b38096685e0928d.css')); ?>"
          type="text/css">
    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-base.min.0af1157cb7ae76fa7ea2eb96300ac6b8.css')); ?>"
          type="text/css">


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/epp/common/ep-cm-g-barcode-scanner-popup/clientlibs/site.min.5578572dd8752920eb8c98daf5371b4b.css')); ?>"
          type="text/css">


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-pf/compact.min.b6ae2d4279ec5f485267288a241f8c6e.css')); ?>"
          type="text/css">


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-pf/compactComp.min.e6a6601f900d813bdb45e160278f5ac4.css')); ?>"
          type="text/css">


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/common/cm-g-notice/clientlibs/site.min.759491f08c70ca0e350c3e4852ec1308.css')); ?>"
          type="text/css"/>

    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/navigation/nv-g-visual-lnb/clientlibs/site.min.679421122255c710e37d07c85da1f2bc.css')); ?>"
          type="text/css"/>

    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product/pd-g-header-carousel/clientlibs/site.min.5a34e744757e41dc5dc7661f95a08ec2.css')); ?>"
          type="text/css"/>

    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product/pd-g-product-finder-v2/clientlibs/site.min.e1e120180ec5594c51df4ba97a8fa04e.css')); ?>"
          type="text/css"/>
<?php /**PATH C:\laragon\www\Test\samsung\admin\resources\views/Fe/layouts/css.blade.php ENDPATH**/ ?>