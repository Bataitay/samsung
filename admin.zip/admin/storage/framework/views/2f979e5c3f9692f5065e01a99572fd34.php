<link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/resources/vn/css/vn.css')); ?>"
          type="text/css"/>


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-dependencies.min.72b3474a5ea9ec2c8b38096685e0928d.css')); ?>"
          type="text/css">
    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-base.min.0af1157cb7ae76fa7ea2eb96300ac6b8.css')); ?>"
          type="text/css">


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/epp/common/ep-cm-g-barcode-scanner-popup/clientlibs/site.min.5578572dd8752920eb8c98daf5371b4b.css')); ?>"
          type="text/css">


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-pf/compact.min.b6ae2d4279ec5f485267288a241f8c6e.css')); ?>"
          type="text/css">


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-pf/compactComp.min.e6a6601f900d813bdb45e160278f5ac4.css')); ?>"
          type="text/css">


    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/common/cm-g-notice/clientlibs/site.min.759491f08c70ca0e350c3e4852ec1308.css')); ?>"
          type="text/css"/>

    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/navigation/nv-g-visual-lnb/clientlibs/site.min.679421122255c710e37d07c85da1f2bc.css')); ?>"
          type="text/css"/>

    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product/pd-g-header-carousel/clientlibs/site.min.5a34e744757e41dc5dc7661f95a08ec2.css')); ?>"
          type="text/css"/>

    <link rel="stylesheet"
          href="<?php echo e(asset('/figer/www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product/pd-g-product-finder-v2/clientlibs/site.min.e1e120180ec5594c51df4ba97a8fa04e.css')); ?>"
          type="text/css"/>
<?php /**PATH C:\laragon\www\Test\samsung\admin\resources\views/Fe/products/style.blade.php ENDPATH**/ ?>