<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between">
    <h3 class="mb-0">Máy giặt</h3>
    <button class="btn btn-primary" type="submit">Xuất excel</button>
</div>
<table class="table table-bordered border-primary mt-5">
    <thead>
    <tr>
        <th scope="col">Stt</th>
        <th scope="col">Model</th>
        <th scope="col">Mô tả</th>
        <th scope="col">Màu sắc</th>
        <th scope="col">Giá niêm yết</th>
        <th scope="col">Giá ưu đãi hiển thị trên website</th>
        <th scope="col">Tồn kho</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td scope="row"><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($item['Model']); ?></td>
        <td><?php echo e($item['description']); ?></td>
        <td><?php echo e($item['color']); ?></td>
        <td><?php echo e($item['afterTaxPriceDisplay']); ?></td>
        <td><?php echo e($item['priceDisplay']); ?></td>
        <td><?php echo e($item['stock']); ?></td>
    </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Test\samsung\admin\resources\views/admin/washing.blade.php ENDPATH**/ ?>